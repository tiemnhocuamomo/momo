TIỆM NHỎ CỦA MỠ MỠ — WEBSITE TĨNH MIỄN PHÍ

CÁCH XEM WEBSITE
1. Giải nén file ZIP.
2. Mở thư mục tiem_nho_mo_mo.
3. Nhấp đúp index.html để xem bằng trình duyệt.

CÁCH CHỈNH SỬA
- Mở index.html bằng Notepad hoặc VS Code.
- Tìm các phần tên sản phẩm, mô tả và giá để sửa nội dung.
- Trong mục Liên hệ, thay dòng hướng dẫn bằng số Zalo/link Zalo và tên/link TikTok thật.
- Ảnh sản phẩm hiện đang là hình minh họa emoji. Có thể thay bằng ảnh sản phẩm thật khi có ảnh.

CÁCH ĐƯA LÊN INTERNET MIỄN PHÍ
Bạn có thể dùng GitHub Pages:
1. Tạo tài khoản tại https://github.com/
2. Tạo repository mới, ví dụ: tiem-nho-mo-mo.
3. Tải file index.html lên repository.
4. Vào Settings > Pages.
5. Chọn Deploy from a branch, chọn nhánh main và thư mục /(root), nhấn Save.
6. Chờ GitHub công bố website và mở đường dẫn được hiển thị trong Settings > Pages.

LƯU Ý
- Website này là trang giới thiệu/trưng bày sản phẩm tĩnh; không có giỏ hàng, thanh toán trực tuyến hay cơ sở dữ liệu đơn hàng.
- Form đặt hàng tạo file tin nhắn .txt để bạn sao chép gửi khách/shop; không tự gửi đơn đi đâu.
- Hosting GitHub Pages phù hợp cho website giới thiệu tĩnh, miễn phí theo điều khoản hiện hành. Tên miền riêng là tùy chọn và thường phải trả phí.
